// Function to add a product to the cart
function addToCart(productName) {
    let cart = JSON.parse(localStorage.getItem('cart')) || [];
    cart.push(productName);
    localStorage.setItem('cart', JSON.stringify(cart));
    alert(`${productName} added to cart`);
}

// Function to view the cart and redirect to payment page
function viewCart() {
    let cart = JSON.parse(localStorage.getItem('cart')) || [];
    if (cart.length > 0) {
        let location = prompt("Please enter your location:");
        if (location) {
            window.location.href = "payment.html"; // Change to your actual payment gateway URL
        }
    } else {
        alert("Your cart is empty");
    }
}

// Event listener for the 'View Cart' button
document.querySelector('#view-cart-button')?.addEventListener('click', viewCart);
